// Lommeregner med GUI


